import contract from './contract.json'

const CONTRACT_ADDRESS = '0x3d7da6ceb7605e411a104996214ed5c00dDBE9Fd'

const SUBGRAPH_LINK =
    'https://ipfs.io/ipfs/QmPY529XqN4MUjmSA16sgAtm2seWj9HA5FSNnfVLa9YKC3'

const ABI = contract.abi
export default CONTRACT_ADDRESS
export { ABI }
